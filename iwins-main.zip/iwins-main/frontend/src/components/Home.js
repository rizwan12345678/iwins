import React from 'react'
import TaskBoard from "./Dashboard"

function Home() {
  return (
    <div>
      <h1>HOmePAge</h1>
    </div>
  )
}

export default Home