import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from "react-redux";
import { fetchtasks, posttasks, updatetasks, deletetasks } from "../redux/features/taskSlice";

const TaskBoard = () => {
  const [sname, setSname] = useState("")
  const tasksDataFinal = useSelector(state => state.task)
  const dispatch = useDispatch()
  useEffect(() => {
    dispatch(fetchtasks());
  }, []);

  const addtaskHandler = async (e) => {
    e.preventDefault()
    const taskDetails = { task: sname, }
    try {
      const response = await dispatch(posttasks(taskDetails))
      if(response){
        dispatch(fetchtasks())
      }
    } catch (err) {
      console.error(err)
    }

    // console.log(taskDetails)
    setSname("")
  }


  const updatePost = (e) => {
    e.preventDefault()
    const taskDetails = { task: sname, }
    // console.log(taskDetails)
    dispatch(updatetasks(taskDetails))
    setSname("")
  }

  const deletePost =async (id) => {
    // console.log(taskDetails)
    try {
      const response = await dispatch(deletetasks(id))
      console.log(response)
     
        dispatch(fetchtasks());
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <>
      <form action="">
        <label for="Sname">Second name:</label>
        <input type="text" id="Sname" name="Sname" value={sname} onChange={(e) => setSname(e.target.value)} />
        <input type="submit" value="Submit" onClick={addtaskHandler} />
        <input type="submit" value="Update" onClick={updatePost} />
      </form>

      {/* show task */}
      <div>All task List</div>
      <div className="tasklist">
        <div className="display-tasks">
          <h3>Your tasks:</h3>
          {(tasksDataFinal.taskData).length >= 1 ?
            <ul className="tasks">
              {(tasksDataFinal.taskData).map((task) => (
                <li className="task" key={task._id}>
                  {task.task},{task._id}
                  <button
                    className="delete-btn"
                    onClick={() => deletePost(task._id)}
                  >
                    delete
                  </button>
                </li>
              ))}
            </ul> : <div>NO data</div>
          }
        </div>
      </div>
    </>

  )
}

export default TaskBoard;