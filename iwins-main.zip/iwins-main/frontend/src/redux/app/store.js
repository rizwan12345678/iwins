import { configureStore } from "@reduxjs/toolkit";
import taskReducer from "../features/taskSlice" 
import authReducer from "../features/authSlice";

//create store

export const store = configureStore({
    reducer:{
        task:taskReducer,
        authData:authReducer,
    },
})