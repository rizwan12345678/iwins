import { createSlice, createAsyncThunk, nanoid } from "@reduxjs/toolkit";
import axios from 'axios';

const initialState ={
  isLoading: false,
  taskData: [],
  isError: false,
};
const apiBaseUrl = "http://localhost:5000/api"
// Action
export const fetchtasks = createAsyncThunk("fetchtasks", async () => {
  const response = await fetch(`${apiBaseUrl}/get`);
  return response.json();
});

export const posttasks = createAsyncThunk(
  "type/posttasks",
  async (data) => {
    try {
      const response = await axios.post(`${apiBaseUrl}/save`, data);
      // If you want to get something back
      return response.data;
    } catch (err) {
      console.error(err)
    }
  }
);

export const updatetasks = createAsyncThunk(
  "type/updateData",
  async (data) => {
    try {
      const response = await axios.post(`${apiBaseUrl}/update/id`, data);
      // If you want to get something back
      return response.data;
    } catch (err) {
      console.error(err)
    }
  }
);

export const deletetasks = createAsyncThunk(
  "type/deleteData",
  async (id, thunkAPI) => {
    try {
      axios.delete(`${apiBaseUrl}/delete/${id}`)
  .then(response => {
    console.log(`Deleted post with ID ${id}`)
  })
    } catch (err) {
      return thunkAPI.rejectWithValue(err.response.data.message);
    }
  }
);

const taskSlice = createSlice({
  name: "task",
 initialState,
  reducers: {},

  //for get data
  extraReducers: (builder) => {
    builder.addCase(fetchtasks.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(fetchtasks.fulfilled, (state, action) => {
      state.isLoading = false;
      state.taskData = action.payload;
    });
    builder.addCase(fetchtasks.rejected, (state, action) => {
      console.log("Error", action.payload);
      state.isError = true;
    });

  //for post data
    builder.addCase(posttasks.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(posttasks.fulfilled, (state, action) => {
      state.isLoading = false;
    });
    builder.addCase(posttasks.rejected, (state, action) => {
      console.log("Error", action.payload);
      state.isError = true;
    });

    //for update data
    builder.addCase(updatetasks.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(updatetasks.fulfilled, (state, action) => {
      state.isLoading = false;
    });
    builder.addCase(updatetasks.rejected, (state, action) => {
      console.log("Error", action.payload);
      state.isError = true;
    });

    //for delete data
    builder.addCase(deletetasks.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(deletetasks.fulfilled, (state, action) => {
      state.isLoading = false
    });
    builder.addCase(deletetasks.rejected, (state, action) => {
      console.log("Error", action.payload);
      state.isError = true;
    });
  },
});

export default taskSlice.reducer;
export const {  } = taskSlice.actions