import React from 'react'
import "../src/styles/styles.css"
import { Routes } from './Router/Routes';
import Navbar from './components/Navbar';
import Footer from './components/Footer';


const App = () => {
  return (
    <>
      <Navbar />
      <div style={{marginTop:"60px"}}><Routes /></div>
      <Footer />
    </>
  )
}

export default App;