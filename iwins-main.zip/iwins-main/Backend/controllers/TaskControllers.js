const TaskModel = require("../models/TaskModels")

module.exports.getTasks = async (req, res) => {
    const task = await TaskModel.find()
    res.send(task)
    // res.send("HIii")
}

module.exports.SaveTask = async (req, res) => {
    const { task } = req.body
    TaskModel.create({ task })
        .then((data) => {
            console.log("Saved successfully");
            res.status(201).send(data)
        }).catch((err) => {
            console.log(err);
            res.send({ error: err, msg: "Something went wrong!" })
        })
}

module.exports.UpdateTask = async (req, res) => {
    const { id } = req.params
    const { task } = req.body

    TaskModel.findByIdAndUpdate(id,{ task })
        .then(() => {
            res.send("Updated successfully")
        }).catch((err) => {
            console.log(err);
            res.send({ error: err, msg: "Something went wrong!" })
        })
}

module.exports.DeleteTask = async (req, res) => {
    const { id } = req.params

    TaskModel.findByIdAndDelete(id)
        .then(() => {
            res.send("Deleted successfully")
        }).catch((err) => {
            console.log(err);
            res.send({ error: err, msg: "Something went wrong!" })
        })
}