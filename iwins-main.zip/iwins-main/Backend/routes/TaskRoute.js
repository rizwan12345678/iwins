const {Router} = require("express")

const {getTasks, SaveTask, DeleteTask, UpdateTask}= require("../controllers/TaskControllers")

const router = Router()

router.get("/get", getTasks)
router.post("/save", SaveTask)
router.put("/update/:id", UpdateTask)
router.delete("/delete/:id", DeleteTask)
module.exports=router